/*
  # University Management System Initial Schema

  1. New Tables
    - users (managed by Supabase Auth)
    - students
      - Basic student information
      - Linked to courses through enrollments
    - faculty
      - Professor and staff information
    - departments
      - Academic departments
    - courses
      - Course information
      - Linked to departments
    - enrollments
      - Links students to courses
      - Tracks grades and enrollment status
    - assignments
      - Course assignments and deadlines
    - submissions
      - Student assignment submissions
    
  2. Security
    - RLS enabled on all tables
    - Policies for different user roles (students, faculty, admin)
    
  3. Relationships
    - Students can view their own data and enrolled courses
    - Faculty can manage their courses and view enrolled students
    - Admins have full access
*/

-- Create custom types
CREATE TYPE user_role AS ENUM ('student', 'faculty', 'admin');
CREATE TYPE enrollment_status AS ENUM ('enrolled', 'dropped', 'completed');
CREATE TYPE grade AS ENUM ('A', 'B', 'C', 'D', 'F', 'I', 'W');

-- Departments
CREATE TABLE IF NOT EXISTS departments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text NOT NULL UNIQUE,
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Faculty
CREATE TABLE IF NOT EXISTS faculty (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  department_id uuid REFERENCES departments,
  first_name text NOT NULL,
  last_name text NOT NULL,
  email text NOT NULL UNIQUE,
  title text,
  phone text,
  office_location text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Students
CREATE TABLE IF NOT EXISTS students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  student_id text UNIQUE NOT NULL,
  first_name text NOT NULL,
  last_name text NOT NULL,
  email text NOT NULL UNIQUE,
  date_of_birth date,
  phone text,
  address text,
  major text,
  enrollment_date date DEFAULT CURRENT_DATE,
  graduation_date date,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Courses
CREATE TABLE IF NOT EXISTS courses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  department_id uuid REFERENCES departments NOT NULL,
  code text NOT NULL,
  name text NOT NULL,
  description text,
  credits integer NOT NULL,
  capacity integer NOT NULL,
  faculty_id uuid REFERENCES faculty,
  semester text NOT NULL,
  year integer NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(code, semester, year)
);

-- Enrollments
CREATE TABLE IF NOT EXISTS enrollments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid REFERENCES students NOT NULL,
  course_id uuid REFERENCES courses NOT NULL,
  status enrollment_status DEFAULT 'enrolled',
  grade grade,
  enrollment_date timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(student_id, course_id)
);

-- Assignments
CREATE TABLE IF NOT EXISTS assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid REFERENCES courses NOT NULL,
  title text NOT NULL,
  description text,
  due_date timestamptz NOT NULL,
  max_points integer NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Submissions
CREATE TABLE IF NOT EXISTS submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  assignment_id uuid REFERENCES assignments NOT NULL,
  student_id uuid REFERENCES students NOT NULL,
  submission_text text,
  submission_url text,
  points_earned numeric,
  submitted_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(assignment_id, student_id)
);

-- Enable RLS
ALTER TABLE departments ENABLE ROW LEVEL SECURITY;
ALTER TABLE faculty ENABLE ROW LEVEL SECURITY;
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE enrollments ENABLE ROW LEVEL SECURITY;
ALTER TABLE assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE submissions ENABLE ROW LEVEL SECURITY;

-- Policies

-- Departments
CREATE POLICY "Public can view departments"
  ON departments FOR SELECT
  TO authenticated
  USING (true);

-- Faculty policies
CREATE POLICY "Faculty can view own profile"
  ON faculty FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Faculty can update own profile"
  ON faculty FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Student policies
CREATE POLICY "Students can view own profile"
  ON students FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Students can update own profile"
  ON students FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Course policies
CREATE POLICY "Anyone can view courses"
  ON courses FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Faculty can manage own courses"
  ON courses FOR ALL
  TO authenticated
  USING (faculty_id IN (SELECT id FROM faculty WHERE user_id = auth.uid()));

-- Enrollment policies
CREATE POLICY "Students can view own enrollments"
  ON enrollments FOR SELECT
  TO authenticated
  USING (student_id IN (SELECT id FROM students WHERE user_id = auth.uid()));

CREATE POLICY "Faculty can view course enrollments"
  ON enrollments FOR SELECT
  TO authenticated
  USING (course_id IN (SELECT id FROM courses WHERE faculty_id IN 
    (SELECT id FROM faculty WHERE user_id = auth.uid())));

-- Assignment policies
CREATE POLICY "Students can view course assignments"
  ON assignments FOR SELECT
  TO authenticated
  USING (course_id IN (
    SELECT course_id FROM enrollments WHERE student_id IN 
    (SELECT id FROM students WHERE user_id = auth.uid())
  ));

CREATE POLICY "Faculty can manage course assignments"
  ON assignments FOR ALL
  TO authenticated
  USING (course_id IN (
    SELECT id FROM courses WHERE faculty_id IN 
    (SELECT id FROM faculty WHERE user_id = auth.uid())
  ));

-- Submission policies
CREATE POLICY "Students can manage own submissions"
  ON submissions FOR ALL
  TO authenticated
  USING (student_id IN (SELECT id FROM students WHERE user_id = auth.uid()));

CREATE POLICY "Faculty can view course submissions"
  ON submissions FOR SELECT
  TO authenticated
  USING (assignment_id IN (
    SELECT id FROM assignments WHERE course_id IN 
    (SELECT id FROM courses WHERE faculty_id IN 
      (SELECT id FROM faculty WHERE user_id = auth.uid()))
  ));