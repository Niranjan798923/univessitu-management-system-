import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { School, BookOpen, Users, GraduationCap, LogOut } from 'lucide-react';

const Navbar = () => {
  const navigate = useNavigate();
  
  const handleLogout = () => {
    // In a real app, you would clear authentication tokens here
    // For now, we'll just redirect to the home page
    navigate('/');
  };

  return (
    <nav className="bg-indigo-600 text-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center space-x-2">
            <School className="h-8 w-8" />
            <span className="font-bold text-xl">UniManager</span>
          </Link>
          
          <div className="hidden md:flex space-x-8">
            <Link to="/courses" className="flex items-center space-x-1 hover:text-indigo-200">
              <BookOpen className="h-5 w-5" />
              <span>Courses</span>
            </Link>
            <Link to="/students" className="flex items-center space-x-1 hover:text-indigo-200">
              <Users className="h-5 w-5" />
              <span>Students</span>
            </Link>
            <Link to="/faculty" className="flex items-center space-x-1 hover:text-indigo-200">
              <GraduationCap className="h-5 w-5" />
              <span>Faculty</span>
            </Link>
          </div>

          <button 
            onClick={handleLogout}
            className="flex items-center space-x-1 hover:text-indigo-200"
          >
            <LogOut className="h-5 w-5" />
            <span>Logout</span>
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;