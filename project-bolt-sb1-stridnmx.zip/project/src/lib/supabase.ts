// This file is kept as a placeholder for future database integration
export const dummyExport = {};