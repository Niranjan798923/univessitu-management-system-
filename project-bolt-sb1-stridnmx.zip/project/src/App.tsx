import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Dashboard from './pages/Dashboard';
import Courses from './pages/Courses';
import Students from './pages/Students';
import Faculty from './pages/Faculty';
import Login from './pages/Login';
import AdminDashboard from './pages/AdminDashboard';
import Navbar from './components/Navbar';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route
          path="/dashboard"
          element={
            <>
              <Navbar />
              <div className="container mx-auto px-4 py-8">
                <Dashboard />
              </div>
            </>
          }
        />
        <Route
          path="/admin"
          element={
            <>
              <Navbar />
              <div className="container mx-auto px-4 py-8">
                <AdminDashboard />
              </div>
            </>
          }
        />
        <Route
          path="/courses"
          element={
            <>
              <Navbar />
              <div className="container mx-auto px-4 py-8">
                <Courses />
              </div>
            </>
          }
        />
        <Route
          path="/students"
          element={
            <>
              <Navbar />
              <div className="container mx-auto px-4 py-8">
                <Students />
              </div>
            </>
          }
        />
        <Route
          path="/faculty"
          element={
            <>
              <Navbar />
              <div className="container mx-auto px-4 py-8">
                <Faculty />
              </div>
            </>
          }
        />
        <Route path="/login" element={<Login />} />
        <Route path="/faculty-login" element={<Login />} />
        <Route path="/admin-login" element={<Login />} />
      </Routes>
    </Router>
  );
}

export default App;