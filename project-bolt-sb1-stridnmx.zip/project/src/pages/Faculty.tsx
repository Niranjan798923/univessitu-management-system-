import React, { useState } from 'react';
import { Search, UserPlus, Mail, Phone, MapPin, X } from 'lucide-react';

// Define faculty interface
interface FacultyMember {
  id: number;
  firstName: string;
  lastName: string;
  initials: string;
  title: string;
  department: string;
  email: string;
  phone: string;
  office: string;
}

const Faculty = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [facultyMembers, setFacultyMembers] = useState<FacultyMember[]>([
    {
      id: 1,
      firstName: "Peter",
      lastName: "Smith",
      initials: "PS",
      title: "Professor of Computer Science",
      department: "Computer Science",
      email: "p.smith@university.edu",
      phone: "+1 (555) 123-4567",
      office: "Room 315"
    },
    {
      id: 2,
      firstName: "Maria",
      lastName: "Rodriguez",
      initials: "MR",
      title: "Associate Professor of Mathematics",
      department: "Mathematics",
      email: "m.rodriguez@university.edu",
      phone: "+1 (555) 234-5678",
      office: "Room 422"
    },
    {
      id: 3,
      firstName: "James",
      lastName: "Wilson",
      initials: "JW",
      title: "Assistant Professor of Physics",
      department: "Physics",
      email: "j.wilson@university.edu",
      phone: "+1 (555) 345-6789",
      office: "Room 218"
    },
    {
      id: 4,
      firstName: "Sarah",
      lastName: "Chen",
      initials: "SC",
      title: "Professor of Biology",
      department: "Biology",
      email: "s.chen@university.edu",
      phone: "+1 (555) 456-7890",
      office: "Room 512"
    },
    {
      id: 5,
      firstName: "Robert",
      lastName: "Johnson",
      initials: "RJ",
      title: "Associate Professor of Chemistry",
      department: "Chemistry",
      email: "r.johnson@university.edu",
      phone: "+1 (555) 567-8901",
      office: "Room 325"
    },
    {
      id: 6,
      firstName: "Emily",
      lastName: "Davis",
      initials: "ED",
      title: "Professor of English Literature",
      department: "English",
      email: "e.davis@university.edu",
      phone: "+1 (555) 678-9012",
      office: "Room 410"
    }
  ]);

  // New faculty form state
  const [newFaculty, setNewFaculty] = useState({
    firstName: '',
    lastName: '',
    title: '',
    department: 'Computer Science',
    email: '',
    phone: '',
    office: ''
  });

  // Handle form input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setNewFaculty(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Create new faculty member
    const newMember: FacultyMember = {
      id: facultyMembers.length + 1,
      ...newFaculty,
      initials: `${newFaculty.firstName.charAt(0)}${newFaculty.lastName.charAt(0)}`
    };
    
    // Add to faculty list
    setFacultyMembers(prev => [...prev, newMember]);
    
    // Reset form and close modal
    setNewFaculty({
      firstName: '',
      lastName: '',
      title: '',
      department: 'Computer Science',
      email: '',
      phone: '',
      office: ''
    });
    setShowAddModal(false);
  };

  // Filter faculty based on search term and selected department
  const filteredFaculty = facultyMembers.filter(faculty => {
    const matchesSearch = searchTerm === '' || 
      faculty.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      faculty.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      faculty.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      faculty.title.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesDepartment = selectedDepartment === '' || 
      faculty.department.toLowerCase() === selectedDepartment.toLowerCase();
    
    return matchesSearch && matchesDepartment;
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Faculty</h1>
        <button 
          className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 flex items-center gap-2"
          onClick={() => setShowAddModal(true)}
        >
          <UserPlus className="h-5 w-5" />
          Add Faculty
        </button>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex gap-4 mb-6">
          <div className="flex-1 relative">
            <input
              type="text"
              placeholder="Search faculty..."
              className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
          <select 
            className="border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            value={selectedDepartment}
            onChange={(e) => setSelectedDepartment(e.target.value)}
          >
            <option value="">All Departments</option>
            <option value="Computer Science">Computer Science</option>
            <option value="Mathematics">Mathematics</option>
            <option value="Physics">Physics</option>
            <option value="Biology">Biology</option>
            <option value="Chemistry">Chemistry</option>
            <option value="English">English</option>
          </select>
        </div>

        {filteredFaculty.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-gray-500">No faculty members found matching your search criteria.</p>
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredFaculty.map((faculty) => (
              <div key={faculty.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start space-x-4">
                  <div className="h-12 w-12 rounded-full bg-indigo-100 flex items-center justify-center">
                    <span className="text-indigo-600 font-semibold">{faculty.initials}</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">Dr. {faculty.firstName} {faculty.lastName}</h3>
                    <p className="text-gray-600 text-sm">{faculty.title}</p>
                  </div>
                </div>
                
                <div className="mt-4 space-y-2">
                  <div className="flex items-center text-sm text-gray-600">
                    <Mail className="h-4 w-4 mr-2" />
                    <span>{faculty.email}</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <Phone className="h-4 w-4 mr-2" />
                    <span>{faculty.phone}</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <MapPin className="h-4 w-4 mr-2" />
                    <span>Office: {faculty.office}</span>
                  </div>
                </div>

                <div className="mt-4 flex space-x-2">
                  <button className="flex-1 bg-indigo-50 text-indigo-600 px-4 py-2 rounded hover:bg-indigo-100">
                    View Profile
                  </button>
                  <button className="flex-1 bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
                    Contact
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Faculty Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Add New Faculty Member</h2>
              <button 
                onClick={() => setShowAddModal(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      First Name
                    </label>
                    <input
                      type="text"
                      name="firstName"
                      value={newFaculty.firstName}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Last Name
                    </label>
                    <input
                      type="text"
                      name="lastName"
                      value={newFaculty.lastName}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Title
                  </label>
                  <input
                    type="text"
                    name="title"
                    value={newFaculty.title}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    required
                    placeholder="e.g. Professor of Computer Science"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Department
                  </label>
                  <select
                    name="department"
                    value={newFaculty.department}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    required
                  >
                    <option value="Computer Science">Computer Science</option>
                    <option value="Mathematics">Mathematics</option>
                    <option value="Physics">Physics</option>
                    <option value="Biology">Biology</option>
                    <option value="Chemistry">Chemistry</option>
                    <option value="English">English</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={newFaculty.email}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    required
                    placeholder="name@university.edu"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Phone
                  </label>
                  <input
                    type="text"
                    name="phone"
                    value={newFaculty.phone}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    required
                    placeholder="+1 (555) 123-4567"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Office
                  </label>
                  <input
                    type="text"
                    name="office"
                    value={newFaculty.office}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    required
                    placeholder="Room 123"
                  />
                </div>
              </div>
              
              <div className="mt-6 flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 border rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
                >
                  Add Faculty
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Faculty;