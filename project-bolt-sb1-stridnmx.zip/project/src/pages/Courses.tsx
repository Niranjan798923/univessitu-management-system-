import React, { useState } from 'react';
import { BookOpen, Search, X } from 'lucide-react';

// Define course interface
interface Course {
  id: number;
  code: string;
  title: string;
  department: string;
  credits: number;
  enrolled: number;
  capacity: number;
  semester: string;
  year: number;
}

const Courses = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [courses, setCourses] = useState<Course[]>([
    {
      id: 1,
      code: "CS101",
      title: "Introduction to Programming",
      department: "Computer Science",
      credits: 3,
      enrolled: 45,
      capacity: 50,
      semester: "Spring",
      year: 2025
    },
    {
      id: 2,
      code: "MATH201",
      title: "Calculus II",
      department: "Mathematics",
      credits: 4,
      enrolled: 38,
      capacity: 40,
      semester: "Spring",
      year: 2025
    },
    {
      id: 3,
      code: "PHYS105",
      title: "Mechanics and Thermodynamics",
      department: "Physics",
      credits: 4,
      enrolled: 32,
      capacity: 35,
      semester: "Spring",
      year: 2025
    },
    {
      id: 4,
      code: "BIO110",
      title: "Introduction to Biology",
      department: "Biology",
      credits: 3,
      enrolled: 48,
      capacity: 50,
      semester: "Spring",
      year: 2025
    },
    {
      id: 5,
      code: "CHEM120",
      title: "General Chemistry",
      department: "Chemistry",
      credits: 4,
      enrolled: 42,
      capacity: 45,
      semester: "Spring",
      year: 2025
    },
    {
      id: 6,
      code: "ENG205",
      title: "Creative Writing",
      department: "English",
      credits: 3,
      enrolled: 25,
      capacity: 30,
      semester: "Spring",
      year: 2025
    }
  ]);

  // New course form state
  const [newCourse, setNewCourse] = useState({
    code: '',
    title: '',
    department: 'Computer Science',
    credits: 3,
    capacity: 30,
    semester: 'Spring',
    year: 2025
  });

  // Handle form input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setNewCourse(prev => ({
      ...prev,
      [name]: ['credits', 'capacity', 'year'].includes(name) ? parseInt(value) : value
    }));
  };

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Create new course
    const newCourseEntry: Course = {
      id: courses.length + 1,
      ...newCourse,
      enrolled: 0
    };
    
    // Add to courses list
    setCourses(prev => [...prev, newCourseEntry]);
    
    // Reset form and close modal
    setNewCourse({
      code: '',
      title: '',
      department: 'Computer Science',
      credits: 3,
      capacity: 30,
      semester: 'Spring',
      year: 2025
    });
    setShowAddModal(false);
  };

  // Filter courses based on search term and selected department
  const filteredCourses = courses.filter(course => {
    const matchesSearch = searchTerm === '' || 
      course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      course.code.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesDepartment = selectedDepartment === '' || 
      course.department.toLowerCase() === selectedDepartment.toLowerCase();
    
    return matchesSearch && matchesDepartment;
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Courses</h1>
        <button 
          className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700"
          onClick={() => setShowAddModal(true)}
        >
          Add Course
        </button>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex gap-4 mb-6">
          <div className="flex-1 relative">
            <input
              type="text"
              placeholder="Search courses..."
              className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
          <select 
            className="border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            value={selectedDepartment}
            onChange={(e) => setSelectedDepartment(e.target.value)}
          >
            <option value="">All Departments</option>
            <option value="Computer Science">Computer Science</option>
            <option value="Mathematics">Mathematics</option>
            <option value="Physics">Physics</option>
            <option value="Biology">Biology</option>
            <option value="Chemistry">Chemistry</option>
            <option value="English">English</option>
          </select>
        </div>

        {filteredCourses.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-gray-500">No courses found matching your search criteria.</p>
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredCourses.map((course) => (
              <div key={course.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-semibold text-lg">{course.code}: {course.title}</h3>
                    <p className="text-gray-600 text-sm mt-1">Department of {course.department}</p>
                  </div>
                  <BookOpen className="h-5 w-5 text-indigo-600" />
                </div>
                <div className="mt-4">
                  <p className="text-sm text-gray-600">Credits: {course.credits}</p>
                  <p className="text-sm text-gray-600">Enrolled: {course.enrolled}/{course.capacity}</p>
                  <p className="text-sm text-gray-600">{course.semester} {course.year}</p>
                </div>
                <button className="mt-4 w-full bg-indigo-50 text-indigo-600 px-4 py-2 rounded hover:bg-indigo-100">
                  View Details
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Course Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Add New Course</h2>
              <button 
                onClick={() => setShowAddModal(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Course Code
                    </label>
                    <input
                      type="text"
                      name="code"
                      value={newCourse.code}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      required
                      placeholder="e.g. CS101"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Credits
                    </label>
                    <select
                      name="credits"
                      value={newCourse.credits}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      required
                    >
                      <option value={1}>1</option>
                      <option value={2}>2</option>
                      <option value={3}>3</option>
                      <option value={4}>4</option>
                      <option value={5}>5</option>
                    </select>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Course Title
                  </label>
                  <input
                    type="text"
                    name="title"
                    value={newCourse.title}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    required
                    placeholder="e.g. Introduction to Programming"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Department
                  </label>
                  <select
                    name="department"
                    value={newCourse.department}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    required
                  >
                    <option value="Computer Science">Computer Science</option>
                    <option value="Mathematics">Mathematics</option>
                    <option value="Physics">Physics</option>
                    <option value="Biology">Biology</option>
                    <option value="Chemistry">Chemistry</option>
                    <option value="English">English</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Capacity
                  </label>
                  <input
                    type="number"
                    name="capacity"
                    value={newCourse.capacity}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    required
                    min={1}
                    max={200}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Semester
                    </label>
                    <select
                      name="semester"
                      value={newCourse.semester}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      required
                    >
                      <option value="Spring">Spring</option>
                      <option value="Summer">Summer</option>
                      <option value="Fall">Fall</option>
                      <option value="Winter">Winter</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Year
                    </label>
                    <select
                      name="year"
                      value={newCourse.year}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      required
                    >
                      <option value={2025}>2025</option>
                      <option value={2026}>2026</option>
                      <option value={2027}>2027</option>
                    </select>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 border rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
                >
                  Add Course
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Courses;