import React from 'react';
import { BookOpen, Users, GraduationCap, Calendar } from 'lucide-react';

const Dashboard = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <DashboardCard
          icon={<BookOpen className="h-8 w-8 text-blue-500" />}
          title="Total Courses"
          value="24"
          change="+2 this semester"
        />
        <DashboardCard
          icon={<Users className="h-8 w-8 text-green-500" />}
          title="Active Students"
          value="1,234"
          change="+82 this year"
        />
        <DashboardCard
          icon={<GraduationCap className="h-8 w-8 text-purple-500" />}
          title="Faculty Members"
          value="89"
          change="+4 this year"
        />
        <DashboardCard
          icon={<Calendar className="h-8 w-8 text-red-500" />}
          title="Current Semester"
          value="Spring 2025"
          change="Ends in 45 days"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Recent Announcements</h2>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="border-b pb-4">
                <h3 className="font-medium">Important Update {i}</h3>
                <p className="text-gray-600 text-sm mt-1">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                </p>
                <span className="text-xs text-gray-500 mt-2">2 hours ago</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Upcoming Events</h2>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-start space-x-4">
                <div className="flex-shrink-0 bg-indigo-100 rounded-lg p-2 text-center w-16">
                  <span className="block text-sm font-semibold">Mar</span>
                  <span className="block text-lg font-bold">{i + 14}</span>
                </div>
                <div>
                  <h3 className="font-medium">Event Title {i}</h3>
                  <p className="text-gray-600 text-sm">10:00 AM - 11:30 AM</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const DashboardCard = ({ icon, title, value, change }) => {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center justify-between">
        {icon}
        <span className="text-xs text-gray-500">{change}</span>
      </div>
      <h3 className="text-xl font-semibold mt-4">{value}</h3>
      <p className="text-gray-600">{title}</p>
    </div>
  );
};

export default Dashboard;