import React, { useState } from 'react';
import { School } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const location = useLocation();

  // Predefined credentials
  const validCredentials = {
    student: {
      email: 'student@university.edu',
      password: 'student123',
      redirect: '/dashboard'
    },
    faculty: {
      email: 'faculty@university.edu',
      password: 'faculty123',
      redirect: '/dashboard'
    },
    admin: {
      email: 'admin@university.edu',
      password: 'admin123',
      redirect: '/admin'
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      // Check credentials
      if (email === validCredentials.student.email && password === validCredentials.student.password) {
        navigate(validCredentials.student.redirect);
      } else if (email === validCredentials.faculty.email && password === validCredentials.faculty.password) {
        navigate(validCredentials.faculty.redirect);
      } else if (email === validCredentials.admin.email && password === validCredentials.admin.password) {
        navigate(validCredentials.admin.redirect);
      } else {
        throw new Error('Invalid credentials');
      }
    } catch (err) {
      setError('Invalid email or password');
    } finally {
      setLoading(false);
    }
  };

  const isAdminLogin = location.pathname === '/admin-login';
  const isFacultyLogin = location.pathname === '/faculty-login';

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div>
          <div className="flex justify-center">
            <School className="h-12 w-12 text-indigo-600" />
          </div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
            {isAdminLogin ? 'Admin Login' : isFacultyLogin ? 'Faculty Login' : 'Student Login'}
          </h2>
          <div className="mt-2 text-center text-sm text-gray-600">
            <p className="font-medium">Demo Credentials:</p>
            <p className="text-xs mt-1">
              {isAdminLogin ? (
                <>Admin Email: admin@university.edu<br />Password: admin123</>
              ) : isFacultyLogin ? (
                <>Faculty Email: faculty@university.edu<br />Password: faculty123</>
              ) : (
                <>Student Email: student@university.edu<br />Password: student123</>
              )}
            </p>
          </div>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleLogin}>
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded">
              {error}
            </div>
          )}
          <div className="rounded-md shadow-sm space-y-4">
            <div>
              <label htmlFor="email" className="sr-only">
                Email address
              </label>
              <input
                id="email"
                name="email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="appearance-none rounded relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm"
                placeholder="Email address"
              />
            </div>
            <div>
              <label htmlFor="password" className="sr-only">
                Password
              </label>
              <input
                id="password"
                name="password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="appearance-none rounded relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm"
                placeholder="Password"
              />
            </div>
          </div>

          <div>
            <button
              type="submit"
              disabled={loading}
              className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Signing in...' : 'Sign in'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;